﻿namespace Week07Homework
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSearchProductTotalPrice = new System.Windows.Forms.Label();
            this.btncal = new System.Windows.Forms.Button();
            this.tbxSearchProductCount = new System.Windows.Forms.TextBox();
            this.lblSearchProductTotalPriceHead = new System.Windows.Forms.Label();
            this.lblSearchProductCountHead = new System.Windows.Forms.Label();
            this.lblSearchProductRegDateHead = new System.Windows.Forms.Label();
            this.lblsearchProductStockHead = new System.Windows.Forms.Label();
            this.lblsearchProductSalePriceHead = new System.Windows.Forms.Label();
            this.lblsearchProductPriceHead = new System.Windows.Forms.Label();
            this.lblsearchProductCodeHead = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSearchProductRegDate = new System.Windows.Forms.Label();
            this.lblSearchProductStock = new System.Windows.Forms.Label();
            this.lblSearchProductSalePrice = new System.Windows.Forms.Label();
            this.lblSearchProductPrice = new System.Windows.Forms.Label();
            this.lblSearchProductCode = new System.Windows.Forms.Label();
            this.lblSearchProductName = new System.Windows.Forms.Label();
            this.lblsearchProductNameHead = new System.Windows.Forms.Label();
            this.lbxSearchProduct = new System.Windows.Forms.ListBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.tbxSearchNameCode = new System.Windows.Forms.TextBox();
            this.lblSearchNameCode = new System.Windows.Forms.Label();
            this.btnInput = new System.Windows.Forms.Button();
            this.tbxInputProductStock = new System.Windows.Forms.TextBox();
            this.tbxInputProductPrice = new System.Windows.Forms.TextBox();
            this.tbxInputProductName = new System.Windows.Forms.TextBox();
            this.lblInputProductStock = new System.Windows.Forms.Label();
            this.lblInputProductPrice = new System.Windows.Forms.Label();
            this.lblInputProductName = new System.Windows.Forms.Label();
            this.gbxSearch = new System.Windows.Forms.GroupBox();
            this.gbxInput = new System.Windows.Forms.GroupBox();
            this.gbxSearch.SuspendLayout();
            this.gbxInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSearchProductTotalPrice
            // 
            this.lblSearchProductTotalPrice.BackColor = System.Drawing.Color.White;
            this.lblSearchProductTotalPrice.Location = new System.Drawing.Point(650, 550);
            this.lblSearchProductTotalPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductTotalPrice.Name = "lblSearchProductTotalPrice";
            this.lblSearchProductTotalPrice.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductTotalPrice.TabIndex = 10;
            // 
            // btncal
            // 
            this.btncal.Location = new System.Drawing.Point(827, 488);
            this.btncal.Margin = new System.Windows.Forms.Padding(5);
            this.btncal.Name = "btncal";
            this.btncal.Size = new System.Drawing.Size(88, 45);
            this.btncal.TabIndex = 9;
            this.btncal.Text = "계산";
            this.btncal.UseVisualStyleBackColor = true;
            this.btncal.Click += new System.EventHandler(this.btncal_Click);
            // 
            // tbxSearchProductCount
            // 
            this.tbxSearchProductCount.Location = new System.Drawing.Point(645, 493);
            this.tbxSearchProductCount.Margin = new System.Windows.Forms.Padding(5);
            this.tbxSearchProductCount.Name = "tbxSearchProductCount";
            this.tbxSearchProductCount.Size = new System.Drawing.Size(175, 35);
            this.tbxSearchProductCount.TabIndex = 8;
            // 
            // lblSearchProductTotalPriceHead
            // 
            this.lblSearchProductTotalPriceHead.AutoSize = true;
            this.lblSearchProductTotalPriceHead.Location = new System.Drawing.Point(444, 563);
            this.lblSearchProductTotalPriceHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductTotalPriceHead.Name = "lblSearchProductTotalPriceHead";
            this.lblSearchProductTotalPriceHead.Size = new System.Drawing.Size(82, 24);
            this.lblSearchProductTotalPriceHead.TabIndex = 7;
            this.lblSearchProductTotalPriceHead.Text = "총가격";
            // 
            // lblSearchProductCountHead
            // 
            this.lblSearchProductCountHead.AutoSize = true;
            this.lblSearchProductCountHead.Location = new System.Drawing.Point(442, 493);
            this.lblSearchProductCountHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductCountHead.Name = "lblSearchProductCountHead";
            this.lblSearchProductCountHead.Size = new System.Drawing.Size(58, 24);
            this.lblSearchProductCountHead.TabIndex = 7;
            this.lblSearchProductCountHead.Text = "수량";
            // 
            // lblSearchProductRegDateHead
            // 
            this.lblSearchProductRegDateHead.AutoSize = true;
            this.lblSearchProductRegDateHead.Location = new System.Drawing.Point(442, 389);
            this.lblSearchProductRegDateHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductRegDateHead.Name = "lblSearchProductRegDateHead";
            this.lblSearchProductRegDateHead.Size = new System.Drawing.Size(106, 24);
            this.lblSearchProductRegDateHead.TabIndex = 7;
            this.lblSearchProductRegDateHead.Text = "등록일자";
            // 
            // lblsearchProductStockHead
            // 
            this.lblsearchProductStockHead.AutoSize = true;
            this.lblsearchProductStockHead.Location = new System.Drawing.Point(442, 320);
            this.lblsearchProductStockHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsearchProductStockHead.Name = "lblsearchProductStockHead";
            this.lblsearchProductStockHead.Size = new System.Drawing.Size(58, 24);
            this.lblsearchProductStockHead.TabIndex = 7;
            this.lblsearchProductStockHead.Text = "재고";
            // 
            // lblsearchProductSalePriceHead
            // 
            this.lblsearchProductSalePriceHead.AutoSize = true;
            this.lblsearchProductSalePriceHead.Location = new System.Drawing.Point(442, 254);
            this.lblsearchProductSalePriceHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsearchProductSalePriceHead.Name = "lblsearchProductSalePriceHead";
            this.lblsearchProductSalePriceHead.Size = new System.Drawing.Size(106, 24);
            this.lblsearchProductSalePriceHead.TabIndex = 7;
            this.lblsearchProductSalePriceHead.Text = "할인가격";
            // 
            // lblsearchProductPriceHead
            // 
            this.lblsearchProductPriceHead.AutoSize = true;
            this.lblsearchProductPriceHead.Location = new System.Drawing.Point(442, 184);
            this.lblsearchProductPriceHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsearchProductPriceHead.Name = "lblsearchProductPriceHead";
            this.lblsearchProductPriceHead.Size = new System.Drawing.Size(58, 24);
            this.lblsearchProductPriceHead.TabIndex = 7;
            this.lblsearchProductPriceHead.Text = "가격";
            // 
            // lblsearchProductCodeHead
            // 
            this.lblsearchProductCodeHead.AutoSize = true;
            this.lblsearchProductCodeHead.Location = new System.Drawing.Point(442, 118);
            this.lblsearchProductCodeHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsearchProductCodeHead.Name = "lblsearchProductCodeHead";
            this.lblsearchProductCodeHead.Size = new System.Drawing.Size(58, 24);
            this.lblsearchProductCodeHead.TabIndex = 7;
            this.lblsearchProductCodeHead.Text = "코드";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(442, 350);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 24);
            this.label7.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(442, 306);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 24);
            this.label6.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(442, 232);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 24);
            this.label5.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(442, 198);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 24);
            this.label4.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(442, 155);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(442, 91);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 24);
            this.label2.TabIndex = 6;
            // 
            // lblSearchProductRegDate
            // 
            this.lblSearchProductRegDate.BackColor = System.Drawing.Color.White;
            this.lblSearchProductRegDate.Location = new System.Drawing.Point(650, 379);
            this.lblSearchProductRegDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductRegDate.Name = "lblSearchProductRegDate";
            this.lblSearchProductRegDate.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductRegDate.TabIndex = 5;
            // 
            // lblSearchProductStock
            // 
            this.lblSearchProductStock.BackColor = System.Drawing.Color.White;
            this.lblSearchProductStock.Location = new System.Drawing.Point(650, 310);
            this.lblSearchProductStock.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductStock.Name = "lblSearchProductStock";
            this.lblSearchProductStock.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductStock.TabIndex = 5;
            // 
            // lblSearchProductSalePrice
            // 
            this.lblSearchProductSalePrice.BackColor = System.Drawing.Color.White;
            this.lblSearchProductSalePrice.Location = new System.Drawing.Point(650, 243);
            this.lblSearchProductSalePrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductSalePrice.Name = "lblSearchProductSalePrice";
            this.lblSearchProductSalePrice.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductSalePrice.TabIndex = 5;
            // 
            // lblSearchProductPrice
            // 
            this.lblSearchProductPrice.BackColor = System.Drawing.Color.White;
            this.lblSearchProductPrice.Location = new System.Drawing.Point(650, 179);
            this.lblSearchProductPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductPrice.Name = "lblSearchProductPrice";
            this.lblSearchProductPrice.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductPrice.TabIndex = 5;
            // 
            // lblSearchProductCode
            // 
            this.lblSearchProductCode.BackColor = System.Drawing.Color.White;
            this.lblSearchProductCode.Location = new System.Drawing.Point(650, 114);
            this.lblSearchProductCode.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductCode.Name = "lblSearchProductCode";
            this.lblSearchProductCode.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductCode.TabIndex = 5;
            // 
            // lblSearchProductName
            // 
            this.lblSearchProductName.BackColor = System.Drawing.Color.White;
            this.lblSearchProductName.Location = new System.Drawing.Point(650, 45);
            this.lblSearchProductName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchProductName.Name = "lblSearchProductName";
            this.lblSearchProductName.Size = new System.Drawing.Size(265, 46);
            this.lblSearchProductName.TabIndex = 5;
            // 
            // lblsearchProductNameHead
            // 
            this.lblsearchProductNameHead.AutoSize = true;
            this.lblsearchProductNameHead.Location = new System.Drawing.Point(442, 53);
            this.lblsearchProductNameHead.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsearchProductNameHead.Name = "lblsearchProductNameHead";
            this.lblsearchProductNameHead.Size = new System.Drawing.Size(58, 24);
            this.lblsearchProductNameHead.TabIndex = 5;
            this.lblsearchProductNameHead.Text = "이름";
            // 
            // lbxSearchProduct
            // 
            this.lbxSearchProduct.FormattingEnabled = true;
            this.lbxSearchProduct.ItemHeight = 24;
            this.lbxSearchProduct.Location = new System.Drawing.Point(29, 202);
            this.lbxSearchProduct.Margin = new System.Windows.Forms.Padding(5);
            this.lbxSearchProduct.Name = "lbxSearchProduct";
            this.lbxSearchProduct.Size = new System.Drawing.Size(321, 172);
            this.lbxSearchProduct.TabIndex = 4;
            this.lbxSearchProduct.SelectedIndexChanged += new System.EventHandler(this.lbxSearchProduct_SelectedIndexChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(29, 152);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(325, 40);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "조회";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // tbxSearchNameCode
            // 
            this.tbxSearchNameCode.Location = new System.Drawing.Point(29, 94);
            this.tbxSearchNameCode.Margin = new System.Windows.Forms.Padding(5);
            this.tbxSearchNameCode.Name = "tbxSearchNameCode";
            this.tbxSearchNameCode.Size = new System.Drawing.Size(322, 35);
            this.tbxSearchNameCode.TabIndex = 3;
            // 
            // lblSearchNameCode
            // 
            this.lblSearchNameCode.AutoSize = true;
            this.lblSearchNameCode.Location = new System.Drawing.Point(24, 53);
            this.lblSearchNameCode.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSearchNameCode.Name = "lblSearchNameCode";
            this.lblSearchNameCode.Size = new System.Drawing.Size(138, 24);
            this.lblSearchNameCode.TabIndex = 0;
            this.lblSearchNameCode.Text = "이름 && 코드";
            // 
            // btnInput
            // 
            this.btnInput.AutoSize = true;
            this.btnInput.Location = new System.Drawing.Point(136, 203);
            this.btnInput.Margin = new System.Windows.Forms.Padding(5);
            this.btnInput.Name = "btnInput";
            this.btnInput.Size = new System.Drawing.Size(325, 56);
            this.btnInput.TabIndex = 2;
            this.btnInput.Text = "등록";
            this.btnInput.UseVisualStyleBackColor = true;
            this.btnInput.Click += new System.EventHandler(this.btnInput_Click);
            // 
            // tbxInputProductStock
            // 
            this.tbxInputProductStock.Location = new System.Drawing.Point(136, 146);
            this.tbxInputProductStock.Margin = new System.Windows.Forms.Padding(5);
            this.tbxInputProductStock.Name = "tbxInputProductStock";
            this.tbxInputProductStock.Size = new System.Drawing.Size(322, 35);
            this.tbxInputProductStock.TabIndex = 1;
            // 
            // tbxInputProductPrice
            // 
            this.tbxInputProductPrice.Location = new System.Drawing.Point(136, 91);
            this.tbxInputProductPrice.Margin = new System.Windows.Forms.Padding(5);
            this.tbxInputProductPrice.Name = "tbxInputProductPrice";
            this.tbxInputProductPrice.Size = new System.Drawing.Size(322, 35);
            this.tbxInputProductPrice.TabIndex = 1;
            // 
            // tbxInputProductName
            // 
            this.tbxInputProductName.Location = new System.Drawing.Point(136, 38);
            this.tbxInputProductName.Margin = new System.Windows.Forms.Padding(5);
            this.tbxInputProductName.Name = "tbxInputProductName";
            this.tbxInputProductName.Size = new System.Drawing.Size(322, 35);
            this.tbxInputProductName.TabIndex = 1;
            // 
            // lblInputProductStock
            // 
            this.lblInputProductStock.AutoSize = true;
            this.lblInputProductStock.Location = new System.Drawing.Point(10, 155);
            this.lblInputProductStock.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblInputProductStock.Name = "lblInputProductStock";
            this.lblInputProductStock.Size = new System.Drawing.Size(58, 24);
            this.lblInputProductStock.TabIndex = 0;
            this.lblInputProductStock.Text = "재고";
            // 
            // lblInputProductPrice
            // 
            this.lblInputProductPrice.AutoSize = true;
            this.lblInputProductPrice.Location = new System.Drawing.Point(10, 101);
            this.lblInputProductPrice.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblInputProductPrice.Name = "lblInputProductPrice";
            this.lblInputProductPrice.Size = new System.Drawing.Size(58, 24);
            this.lblInputProductPrice.TabIndex = 0;
            this.lblInputProductPrice.Text = "가격";
            // 
            // lblInputProductName
            // 
            this.lblInputProductName.AutoSize = true;
            this.lblInputProductName.Location = new System.Drawing.Point(10, 46);
            this.lblInputProductName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblInputProductName.Name = "lblInputProductName";
            this.lblInputProductName.Size = new System.Drawing.Size(58, 24);
            this.lblInputProductName.TabIndex = 0;
            this.lblInputProductName.Text = "이름";
            // 
            // gbxSearch
            // 
            this.gbxSearch.Controls.Add(this.lblSearchProductTotalPrice);
            this.gbxSearch.Controls.Add(this.btncal);
            this.gbxSearch.Controls.Add(this.tbxSearchProductCount);
            this.gbxSearch.Controls.Add(this.lblSearchProductTotalPriceHead);
            this.gbxSearch.Controls.Add(this.lblSearchProductCountHead);
            this.gbxSearch.Controls.Add(this.lblSearchProductRegDateHead);
            this.gbxSearch.Controls.Add(this.lblsearchProductStockHead);
            this.gbxSearch.Controls.Add(this.lblsearchProductSalePriceHead);
            this.gbxSearch.Controls.Add(this.lblsearchProductPriceHead);
            this.gbxSearch.Controls.Add(this.lblsearchProductCodeHead);
            this.gbxSearch.Controls.Add(this.label7);
            this.gbxSearch.Controls.Add(this.label6);
            this.gbxSearch.Controls.Add(this.label5);
            this.gbxSearch.Controls.Add(this.label4);
            this.gbxSearch.Controls.Add(this.label3);
            this.gbxSearch.Controls.Add(this.label2);
            this.gbxSearch.Controls.Add(this.lblSearchProductRegDate);
            this.gbxSearch.Controls.Add(this.lblSearchProductStock);
            this.gbxSearch.Controls.Add(this.lblSearchProductSalePrice);
            this.gbxSearch.Controls.Add(this.lblSearchProductPrice);
            this.gbxSearch.Controls.Add(this.lblSearchProductCode);
            this.gbxSearch.Controls.Add(this.lblSearchProductName);
            this.gbxSearch.Controls.Add(this.lblsearchProductNameHead);
            this.gbxSearch.Controls.Add(this.lbxSearchProduct);
            this.gbxSearch.Controls.Add(this.btnSearch);
            this.gbxSearch.Controls.Add(this.tbxSearchNameCode);
            this.gbxSearch.Controls.Add(this.lblSearchNameCode);
            this.gbxSearch.Location = new System.Drawing.Point(538, 29);
            this.gbxSearch.Margin = new System.Windows.Forms.Padding(5);
            this.gbxSearch.Name = "gbxSearch";
            this.gbxSearch.Padding = new System.Windows.Forms.Padding(5);
            this.gbxSearch.Size = new System.Drawing.Size(954, 645);
            this.gbxSearch.TabIndex = 3;
            this.gbxSearch.TabStop = false;
            this.gbxSearch.Text = "상품조회";
            // 
            // gbxInput
            // 
            this.gbxInput.Controls.Add(this.btnInput);
            this.gbxInput.Controls.Add(this.tbxInputProductStock);
            this.gbxInput.Controls.Add(this.tbxInputProductPrice);
            this.gbxInput.Controls.Add(this.tbxInputProductName);
            this.gbxInput.Controls.Add(this.lblInputProductStock);
            this.gbxInput.Controls.Add(this.lblInputProductPrice);
            this.gbxInput.Controls.Add(this.lblInputProductName);
            this.gbxInput.Location = new System.Drawing.Point(25, 28);
            this.gbxInput.Margin = new System.Windows.Forms.Padding(5);
            this.gbxInput.Name = "gbxInput";
            this.gbxInput.Padding = new System.Windows.Forms.Padding(5);
            this.gbxInput.Size = new System.Drawing.Size(471, 341);
            this.gbxInput.TabIndex = 2;
            this.gbxInput.TabStop = false;
            this.gbxInput.Text = "상품등록";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1509, 710);
            this.Controls.Add(this.gbxSearch);
            this.Controls.Add(this.gbxInput);
            this.Name = "Form1";
            this.Text = "7주차 숙제";
            this.gbxSearch.ResumeLayout(false);
            this.gbxSearch.PerformLayout();
            this.gbxInput.ResumeLayout(false);
            this.gbxInput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblSearchProductTotalPrice;
        private System.Windows.Forms.Button btncal;
        private System.Windows.Forms.TextBox tbxSearchProductCount;
        private System.Windows.Forms.Label lblSearchProductTotalPriceHead;
        private System.Windows.Forms.Label lblSearchProductCountHead;
        private System.Windows.Forms.Label lblSearchProductRegDateHead;
        private System.Windows.Forms.Label lblsearchProductStockHead;
        private System.Windows.Forms.Label lblsearchProductSalePriceHead;
        private System.Windows.Forms.Label lblsearchProductPriceHead;
        private System.Windows.Forms.Label lblsearchProductCodeHead;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSearchProductRegDate;
        private System.Windows.Forms.Label lblSearchProductStock;
        private System.Windows.Forms.Label lblSearchProductSalePrice;
        private System.Windows.Forms.Label lblSearchProductPrice;
        private System.Windows.Forms.Label lblSearchProductCode;
        private System.Windows.Forms.Label lblSearchProductName;
        private System.Windows.Forms.Label lblsearchProductNameHead;
        private System.Windows.Forms.ListBox lbxSearchProduct;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox tbxSearchNameCode;
        private System.Windows.Forms.Label lblSearchNameCode;
        private System.Windows.Forms.Button btnInput;
        private System.Windows.Forms.TextBox tbxInputProductStock;
        private System.Windows.Forms.TextBox tbxInputProductPrice;
        private System.Windows.Forms.TextBox tbxInputProductName;
        private System.Windows.Forms.Label lblInputProductStock;
        private System.Windows.Forms.Label lblInputProductPrice;
        private System.Windows.Forms.Label lblInputProductName;
        private System.Windows.Forms.GroupBox gbxSearch;
        private System.Windows.Forms.GroupBox gbxInput;
    }
}

